// OCP ART404CP — dual GenX320 side-by-side capture v3
// EXACT clone of metavision_hal_sync per-camera pipeline, composed into ONE window.
// Each camera gets: own Device, own I_EventsStream, own decode thread with the
// SAME tight poll loop, own EventAnalyzer (identical rendering: direct pixel
// writes, swap-buffer, hal_sync colors). Main thread composes both frames
// side-by-side into one 640x320 window.
// Recording: hw-side log_raw_data on each camera (hal_sync order: before mode set).
//
// Usage: ./capture_sbs_v3 [--master-serial 2629600159] [--slave-serial 2629600155]
//        [--duration SEC(0=until-q)] [--outdir ~/captures] [--no-record]

#include <metavision/hal/device/device.h>
#include <metavision/hal/device/device_discovery.h>
#include <metavision/hal/facilities/i_camera_synchronization.h>
#include <metavision/hal/facilities/i_events_stream.h>
#include <metavision/hal/facilities/i_events_stream_decoder.h>
#include <metavision/hal/facilities/i_event_decoder.h>
#include <metavision/hal/facilities/i_geometry.h>

#include <opencv2/opencv.hpp>

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <mutex>
#include <signal.h>
#include <string>
#include <thread>
#include <unistd.h>

static std::atomic<bool> g_run{true};
static void sig_handler(int) { g_run = false; }

// ===== EXACT copy of metavision_hal_sync EventAnalyzer =====
class EventAnalyzer {
public:
    cv::Mat img, img_swap;
    std::mutex m;
    bool is_waiting_for_master = false;

    cv::Vec3b color_bg  = cv::Vec3b(52, 37, 30);
    cv::Vec3b color_on  = cv::Vec3b(236, 223, 216);
    cv::Vec3b color_off = cv::Vec3b(201, 126, 64);

    void setup_display(const int width, const int height) {
        img      = cv::Mat(height, width, CV_8UC3);
        img_swap = cv::Mat(height, width, CV_8UC3);
        img.setTo(color_bg);
    }

    void get_display_frame(cv::Mat &display) {
        {
            std::unique_lock<std::mutex> lock(m);
            std::swap(img, img_swap);
            img.setTo(color_bg);
        }
        img_swap.copyTo(display);
    }

    void process_events(const Metavision::EventCD *begin, const Metavision::EventCD *end) {
        {
            std::unique_lock<std::mutex> lock(m);
            if (begin->t == 0 && (end - 1)->t == 0) {
                if (!is_waiting_for_master) {
                    std::cout << "===========================" << std::endl;
                    std::cout << "Waiting for master to start" << std::endl;
                    std::cout << "===========================" << std::endl;
                }
                is_waiting_for_master = true;
            } else {
                is_waiting_for_master = false;
            }
            if (!is_waiting_for_master) {
                for (auto it = begin; it != end; ++it) {
                    img.at<cv::Vec3b>(it->y, it->x) = (it->p) ? color_on : color_off;
                }
            }
        }
    }
};

// ===== Per-camera pipeline, mirroring hal_sync main() exactly =====
struct Cam {
    std::string serial, label;
    std::unique_ptr<Metavision::Device> device;
    Metavision::I_EventsStream *es = nullptr;
    Metavision::I_EventDecoder<Metavision::EventCD> *cd_dec = nullptr;
    EventAnalyzer analyzer;
    std::thread decode_thread;
    std::atomic<bool> stop_decoding{false};

    void open(const std::string &sn, const std::string &lb) {
        serial = sn; label = lb;
        std::cout << "Opening camera (" << label << ")..." << std::endl;
        device = Metavision::DeviceDiscovery::open(serial);
        std::cout << "Camera open." << std::endl;
    }

    void start(const std::string &raw_path, bool master) {
        Metavision::I_EventsStream *i_eventsstream = device->get_facility<Metavision::I_EventsStream>();
        if (i_eventsstream) {
            if (!raw_path.empty()) i_eventsstream->log_raw_data(raw_path);
        } else {
            std::cerr << "Could not initialize events stream." << std::endl;
            throw std::runtime_error("no events stream");
        }

        // set master/slave mode
        Metavision::I_CameraSynchronization *i_camera_synchronization =
            device->get_facility<Metavision::I_CameraSynchronization>();
        bool ok = master ? i_camera_synchronization->set_mode_master()
                         : i_camera_synchronization->set_mode_slave();
        if (ok) {
            std::cout << (master ? "Set mode Master successful. Remember to start the slave first."
                                 : "Set mode Slave successful.") << std::endl;
        } else {
            std::cerr << "Could not set " << (master ? "Master" : "Slave") << " mode." << std::endl;
            throw std::runtime_error("mode set failed");
        }

        i_eventsstream->start();
        es = i_eventsstream;

        // geometry + analyzer
        Metavision::I_Geometry *i_geometry = device->get_facility<Metavision::I_Geometry>();
        analyzer.setup_display(i_geometry->get_width(), i_geometry->get_height());

        // decoder + callback (same as hal_sync)
        cd_dec = device->get_facility<Metavision::I_EventDecoder<Metavision::EventCD>>();
        cd_dec->add_event_buffer_callback(
            [this](const Metavision::EventCD *begin, const Metavision::EventCD *end) {
                analyzer.process_events(begin, end);
            });
    }

    void start_decode_loop() {
        // EXACT hal_sync decoding loop
        Metavision::I_EventsStreamDecoder *i_decoder =
            device->get_facility<Metavision::I_EventsStreamDecoder>();
        decode_thread = std::thread([this, i_decoder]() {
            while (!stop_decoding.load()) {
                short ret = es->poll_buffer();
                auto raw_data = es->get_latest_raw_data();
                if (raw_data) {
                    i_decoder->decode(raw_data.begin(), raw_data.data() + raw_data.size());
                }
            }
        });
    }

    void stop() {
        stop_decoding = true;
        if (decode_thread.joinable()) decode_thread.join();
        try { if (es) es->stop(); } catch (...) {}
    }
};

int main(int argc, char **argv) {
    std::string master_sn = "2629600159";
    std::string slave_sn = "2629600155";
    double duration = 0;  // 0 = until 'q'
    std::string outdir = (getenv("HOME") ? std::string(getenv("HOME")) : std::string(".")) + "/captures";
    bool record = true;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--master-serial" && i+1 < argc) master_sn = argv[++i];
        else if (a == "--slave-serial" && i+1 < argc) slave_sn = argv[++i];
        else if (a == "--duration" && i+1 < argc) duration = atof(argv[++i]);
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (a == "--no-record") record = false;
        else if (a == "-h" || a == "--help") {
            std::cout << "usage: capture_sbs_v3 [--master-serial SN] [--slave-serial SN] "
                      << "[--duration SEC(0=until-q)] [--outdir DIR] [--no-record]\n";
            return 0;
        }
    }
    std::filesystem::create_directories(outdir);
    signal(SIGINT, sig_handler);

    char tsbuf[32];
    auto t = std::time(nullptr);
    std::strftime(tsbuf, sizeof(tsbuf), "%Y%m%d_%H%M%S", std::localtime(&t));
    std::string stamp(tsbuf);
    std::string path_m = outdir + "/sbs_master_" + master_sn + "_" + stamp + ".raw";
    std::string path_s = outdir + "/sbs_slave_" + slave_sn + "_" + stamp + ".raw";

    try {
        // hal_sync order: SLAVE FIRST
        Cam slave, master;
        slave.open(slave_sn, "slave");
        slave.start(record ? path_s : "", false);
        slave.start_decode_loop();

        std::this_thread::sleep_for(std::chrono::milliseconds(1500));

        master.open(master_sn, "master");
        master.start(record ? path_m : "", true);
        master.start_decode_loop();

        // compose loop (main thread) — like hal_sync's display loop
        int W = 320, H = 320;
        cv::Mat disp_m, disp_s;
        cv::Mat canvas(H, W * 2 + 4, CV_8UC3, cv::Scalar(20, 20, 20));
        const std::string window_name = "OCP Sync - Slave | Master";
        const int wait_time = static_cast<int>(std::round(1.f / 25.f * 1000));

        auto t0 = std::chrono::steady_clock::now();
        auto last_report = t0;
        while (g_run.load()) {
            slave.analyzer.get_display_frame(disp_s);
            master.analyzer.get_display_frame(disp_m);
            if (!disp_m.empty() && !disp_s.empty()) {
                disp_s.copyTo(cv::Mat(canvas, cv::Rect(0, 0, W, H)));
                disp_m.copyTo(cv::Mat(canvas, cv::Rect(W + 4, 0, W, H)));
                cv::putText(canvas, "SLAVE " + slave_sn, {10, 20}, cv::FONT_HERSHEY_SIMPLEX, 0.5, {200, 200, 0}, 1);
                cv::putText(canvas, "MASTER " + master_sn, {W + 14, 20}, cv::FONT_HERSHEY_SIMPLEX, 0.5, {200, 200, 0}, 1);
                cv::imshow(window_name, canvas);
            }
            int key = cv::waitKey(wait_time) & 0xff;
            if (key == 'q' || key == 27) { std::cout << "q pressed, exiting." << std::endl; break; }
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last_report).count() >= 1.0) {
                std::cout << "[" << (int)std::chrono::duration<double>(now - t0).count()
                          << "s] waiting_m=" << master.analyzer.is_waiting_for_master
                          << " waiting_s=" << slave.analyzer.is_waiting_for_master << std::endl;
                last_report = now;
            }
            if (duration > 0 &&
                std::chrono::duration<double>(now - t0).count() >= duration)
                break;
        }

        master.stop();
        slave.stop();
        if (record) std::cout << "\nraw saved:\n  " << path_m << "\n  " << path_s << "\n";
    } catch (const std::exception &e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
