// OCP ART404CP — dual GenX320 side-by-side capture v2
// Faithfully replicates the WORKING metavision_hal_sync flow:
//   per-camera dedicated decode THREAD, poll->decode loop, log_raw_data before
//   mode programming, slave started first then master.
// Preview: OpenCV side-by-side window (master | slave), 640x320.
// Recording: two raw files (hw-side log_raw_data), shared timestamp.
//
// Usage:
//   ./capture_sidebyside2 [--master-serial 2629600159] [--slave-serial 2629600155]
//       [--duration SEC(0=until-Ctrl-C)] [--outdir ~/captures] [--accum-ms 33] [--no-record]

#include <metavision/hal/device/device.h>
#include <metavision/hal/device/device_discovery.h>
#include <metavision/hal/facilities/i_camera_synchronization.h>
#include <metavision/hal/facilities/i_events_stream.h>
#include <metavision/hal/facilities/i_events_stream_decoder.h>
#include <metavision/hal/facilities/i_event_decoder.h>
#include <metavision/hal/facilities/i_hw_identification.h>
#include <metavision/sdk/base/events/event_cd.h>
#include <metavision/sdk/core/algorithms/base_frame_generation_algorithm.h>

#include <opencv2/opencv.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <signal.h>
#include <string>
#include <thread>
#include <vector>

static std::atomic<bool> g_run{true};
static void sig_handler(int) { g_run = false; }

// Per-camera worker replicating metavision_hal_sync exactly
struct CamWorker {
    std::unique_ptr<Metavision::Device> device;
    std::string serial, label;
    Metavision::I_EventsStream *es = nullptr;
    Metavision::I_EventsStreamDecoder *decoder = nullptr;
    Metavision::I_EventDecoder<Metavision::EventCD> *cd_dec = nullptr;
    std::atomic<uint64_t> n_events{0};
    std::atomic<int64_t> last_ts{-1};
    std::thread decode_thread;
    std::atomic<bool> paused_flag{false};

    void open(const std::string &sn, const std::string &lb) {
        serial = sn; label = lb;
        std::cout << "opening " << label << " " << serial << "...\n";
        device = Metavision::DeviceDiscovery::open(serial);
        es  = device->get_facility<Metavision::I_EventsStream>();
        decoder = device->get_facility<Metavision::I_EventsStreamDecoder>();
        cd_dec  = device->get_facility<Metavision::I_EventDecoder<Metavision::EventCD>>();
    }

    void set_mode(bool master) {
        auto *sync = device->get_facility<Metavision::I_CameraSynchronization>();
        bool ok = master ? sync->set_mode_master() : sync->set_mode_slave();
        if (!ok) throw std::runtime_error("set_mode failed for " + serial);
        std::cout << label << " (" << serial << ") mode " << (master ? "MASTER" : "SLAVE") << " OK\n";
    }

    void start_recording(const std::string &path) {
        if (!path.empty()) {
            es->log_raw_data(path);
            std::cout << label << " recording -> " << path << "\n";
        }
    }

    void start_streaming() { es->start(); }

    std::atomic<uint64_t> raw_bytes{0};
    void start_decode_loop() {
        decode_thread = std::thread([this]() {
            while (g_run.load()) {
                short ret = es->poll_buffer();
                auto raw = es->get_latest_raw_data();
                if (raw && raw.size() > 0) {
                    raw_bytes += raw.size();
                    decoder->decode(raw.begin(), raw.data() + raw.size());
                } else if (ret == 0) {
                    std::this_thread::sleep_for(std::chrono::microseconds(200));
                }
            }
        });
    }

    void stop_decode_loop() {
        if (decode_thread.joinable()) decode_thread.join();
    }
};

int main(int argc, char **argv) {
    std::string master_sn = "2629600159";
    std::string slave_sn = "2629600155";
    double duration = 0;
    std::string outdir = (getenv("HOME") ? std::string(getenv("HOME")) : std::string(".")) + "/captures";
    uint32_t accum_us = 33000;
    bool record = true;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--master-serial" && i+1 < argc) master_sn = argv[++i];
        else if (a == "--slave-serial" && i+1 < argc) slave_sn = argv[++i];
        else if (a == "--duration" && i+1 < argc) duration = atof(argv[++i]);
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (a == "--accum-ms" && i+1 < argc) accum_us = (uint32_t)(atof(argv[++i]) * 1000);
        else if (a == "--no-record") record = false;
        else if (a == "-h" || a == "--help") {
            std::cout << "usage: capture_sidebyside2 [--master-serial SN] [--slave-serial SN] "
                      << "[--duration SEC] [--outdir DIR] [--accum-ms MS] [--no-record]\n";
            return 0;
        }
    }
    std::filesystem::create_directories(outdir);
    signal(SIGINT, sig_handler);

    try {
        char tsbuf[32];
        auto t = std::time(nullptr);
        std::strftime(tsbuf, sizeof(tsbuf), "%Y%m%d_%H%M%S", std::localtime(&t));
        std::string stamp(tsbuf);
        std::string path_m = outdir + "/sbs_master_" + master_sn + "_" + stamp + ".raw";
        std::string path_s = outdir + "/sbs_slave_" + slave_sn + "_" + stamp + ".raw";

        // ---- EXACT metavision_hal_sync sequence ----
        CamWorker slave, master;

        // 1) open SLAVE first
        slave.open(slave_sn, "slave");
        if (record) slave.start_recording(path_s);       // log_raw_data before mode set
        slave.set_mode(false);                            // slave mode
        slave.start_streaming();                          // start slave FIRST
        slave.start_decode_loop();
        std::cout << "slave streaming (waiting for master)\n";

        // 2) wait for slave to enter ts==0 waiting state (hal_sync behaviour)
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));

        // 3) open + configure + start MASTER
        master.open(master_sn, "master");
        if (record) master.start_recording(path_m);
        master.set_mode(true);
        master.start_streaming();
        master.start_decode_loop();
        std::cout << "master streaming\n";

        // ---- preview ----
        int W = 320, H = 320; // GenX320 fixed geometry
        cv::Mat fm(H, W, CV_8UC3, cv::Scalar(0)), fs(H, W, CV_8UC3, cv::Scalar(0));
        std::mutex fm_m, fs_m;
        auto palette = Metavision::ColorPalette::Dark;

        // add preview callbacks after worker callbacks (order fine: both get events)
        bool printed_m = false;
        master.cd_dec->add_event_buffer_callback([&](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            master.n_events += std::distance(b, e);
            if (g_run.load() && !master.paused_flag) {
                std::lock_guard<std::mutex> lk(fm_m);
                Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(b, e, fm, accum_us, palette);
            }
        });
        bool printed_s = false;
        slave.cd_dec->add_event_buffer_callback([&](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            slave.n_events += std::distance(b, e);
            if (g_run.load() && !slave.paused_flag) {
                std::lock_guard<std::mutex> lk(fs_m);
                Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(b, e, fs, accum_us, palette);
            }
        });

        cv::Mat canvas(H, W * 2, CV_8UC3);
        std::string win = "OCP side-by-side (master | slave)";
        cv::namedWindow(win, cv::WINDOW_AUTOSIZE);
        cv::startWindowThread();

        std::cout << "preview running... Ctrl-C to stop\n";
        auto t0 = std::chrono::steady_clock::now();
        auto last_show = std::chrono::steady_clock::now();
        auto last_report = t0;
        uint64_t pm = 0, ps = 0, lrm = 0, lrs = 0;
        int shot = 0;

        while (g_run.load()) {
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last_show).count() >= 1.0/30.0) {
                {
                    std::lock_guard<std::mutex> lk1(fm_m), lk2(fs_m);
                    fm.copyTo(cv::Mat(canvas, cv::Rect(0, 0, W, H)));
                    fs.copyTo(cv::Mat(canvas, cv::Rect(W, 0, W, H)));
                }
                std::string hud = "M:" + std::to_string(master.n_events) + " S:" + std::to_string(slave.n_events)
                                + (record ? "  [REC]" : "") + "  q=quit";
                cv::putText(canvas, hud, {10, 20}, cv::FONT_HERSHEY_SIMPLEX, 0.5, {0,255,0}, 1);
                cv::imshow(win, canvas);
                int key = cv::waitKey(1) & 0xff;
                if (key == 'q' || key == 27) break;
                else if (key == 's' && !outdir.empty()) {
                    cv::imwrite(outdir + "/preview_" + std::to_string(++shot) + ".png", canvas);
                }
                last_show = now;

                double el = std::chrono::duration<double>(now - t0).count();
                if (std::chrono::duration<double>(now - last_report).count() >= 1.0) {
                    std::cout << "[" << (int)el << "s] master: " << (master.n_events - pm)
                              << " ev/s [" << (master.raw_bytes - lrm) << "B] | slave: " << (slave.n_events - ps)
                          << " ev/s [" << (slave.raw_bytes - lrs) << "B]" << std::flush;
                    pm = master.n_events; ps = slave.n_events; lrm = master.raw_bytes; lrs = slave.raw_bytes;
                    last_report = now;
                }
                if (duration > 0 && el >= duration) break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }

        // stop: master first, then slave (reverse of start)
        master.stop_decode_loop();
        slave.stop_decode_loop();
        try { master.es->stop(); } catch (...) {}
        try { slave.es->stop(); } catch (...) {}
        try { master.es->stop_log_raw_data(); } catch (...) {}
        try { slave.es->stop_log_raw_data(); } catch (...) {}
        cv::destroyAllWindows();
        if (record) std::cout << "\nraw saved:\n  " << path_m << "\n  " << path_s << "\n";
        std::cout << "totals: master=" << master.n_events << " slave=" << slave.n_events << "\n";
    } catch (const std::exception &e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
