// OCP ART404CP — event RAW file player with preview window
// Plays Metavision RAW files (EVT2/EVT3), renders accumulating event frames
// at a fixed FPS. Simple, robust: static generate_frame_from_events API.
//
// Build: g++ -O2 -std=c++17 event_raw_player.cpp <includes/libs as capture tool> -o event_raw_player
// Usage: ./event_raw_player <file.raw> [--fps 25] [--accum-ms 50] [--gray] [--outdir DIR]
//
// Keys: SPACE=pause, s=screenshot (needs --outdir), q/ESC=quit

#include <metavision/sdk/stream/camera.h>
#include <metavision/sdk/core/algorithms/base_frame_generation_algorithm.h>
#include <metavision/sdk/base/events/event_cd.h>

#include <opencv2/opencv.hpp>

#include <atomic>
#include <chrono>
#include <filesystem>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>

namespace fs = std::filesystem;

int main(int argc, char **argv) {
    if (argc < 2) {
        std::cerr << "usage: " << argv[0] << " <file.raw> [--fps 25] [--accum-ms 50] [--gray] [--outdir DIR]\n"
                  << "keys: SPACE=pause, s=screenshot, q/ESC=quit\n";
        return 1;
    }
    std::string path = argv[1];
    double fps = 25.0;
    uint32_t accum_us = 50000;
    bool gray = false;
    std::string outdir;

    for (int i = 2; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--fps" && i + 1 < argc) fps = atof(argv[++i]);
        else if (a == "--accum-ms" && i + 1 < argc) accum_us = (uint32_t)(atof(argv[++i]) * 1000);
        else if (a == "--gray") gray = true;
        else if (a == "--outdir" && i + 1 < argc) outdir = argv[++i];
    }
    if (!fs::exists(path)) { std::cerr << "file not found: " << path << "\n"; return 1; }
    if (!outdir.empty()) fs::create_directories(outdir);

    try {
        Metavision::Camera cam = Metavision::Camera::from_file(path);
        const auto &geo = cam.geometry();
        int W = geo.get_width(), H = geo.get_height();
        std::cout << "file: " << path << " geometry: " << W << "x" << H << std::endl;

        cv::Mat frame(H, W, CV_8UC3);
        std::mutex m;
        std::atomic<bool> paused{false};

        auto palette = gray ? Metavision::ColorPalette::Gray : Metavision::ColorPalette::Dark;

        auto cd_cb = cam.cd().add_callback([&](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            if (paused.load()) return;
            std::lock_guard<std::mutex> lk(m);
            // static API: accumulate last accum_us of events into frame
            Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(
                b, e, frame, accum_us, palette);
        });

        std::string win = "event player - " + fs::path(path).filename().string();
        cv::namedWindow(win, cv::WINDOW_AUTOSIZE);

        cam.start();

        auto frame_interval = std::chrono::milliseconds((int)(1000.0 / fps));
        auto last_show = std::chrono::steady_clock::now();
        int shot_id = 0;

        while (true) {
            auto now = std::chrono::steady_clock::now();
            if (now - last_show < frame_interval) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
                continue;
            }
            last_show = now;

            cv::Mat display;
            {
                std::lock_guard<std::mutex> lk(m);
                frame.copyTo(display);
            }
            std::string hud = std::string(paused ? "[PAUSED] " : "") +
                "SPACE=pause s=shot q=quit";
            cv::putText(display, hud, {10, 22}, cv::FONT_HERSHEY_SIMPLEX, 0.5, {0, 255, 0}, 1);
            cv::imshow(win, display);

            int key = cv::waitKey(1) & 0xff;
            if (key == 'q' || key == 27) break;
            else if (key == ' ') paused = !paused;
            else if (key == 's' && !outdir.empty()) {
                cv::imwrite(outdir + "/shot_" + std::to_string(++shot_id) + ".png", display);
                std::cout << "saved shot " << shot_id << "\n";
            }
        }

        cam.stop();
        std::cout << "done\n";
    } catch (const Metavision::CameraException &e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
