# OCP Dual-DVS Capture Tools (ART404CP)

C++ tools for the dual Prophesee GenX320 setup (EVKCX3) on the RK3588 DVS rig,
built against the local openeb build at `~/openeb`.

## Toolchain

| Tool | Purpose |
|---|---|
| `capture_sbs_v3` | **Main tool.** Dual capture (slave 2629600155 first, then master 2629600159), live side-by-side preview window, records two time-synced RAW files. Pipeline cloned from `metavision_hal_sync` (per-camera decode thread, hal_sync EventAnalyzer). |
| `capture_dual_dvs` | Earlier dual capture (SyncedCameraStreamsSlicer-based). |
| `capture_sidebyside` / `capture_sidebyside2` | Intermediate versions; superseded by v3. |
| `capture_single` | Single-camera capture by serial with `--mode standalone|master|slave`. |
| `event_raw_player` | Single RAW file player (OpenCV window). |
| `player_sidebyside` | Plays a recorded master/slave pair side-by-side in one window. |

## Build

```
g++ -O2 -std=c++17 <tool>.cpp \
  -I~/openeb/hal/cpp/include \
  -I~/openeb/sdk/modules/base/cpp/include \
  -I~/openeb/sdk/modules/core/cpp/include \
  -I~/openeb/sdk/modules/stream/cpp/include \
  -I~/openeb/hal_psee_plugins/psee_hw_layer_headers/include \
  -I~/openeb/build/generated/include \
  -I/usr/include/opencv4 \
  -L~/openeb/build/lib \
  -lmetavision_sdk_stream -lmetavision_sdk_core -lmetavision_hal -lmetavision_hal_discovery \
  -lopencv_core -lopencv_imgproc -lopencv_imgcodecs -lopencv_highgui -lopencv_videoio \
  -o <tool>
```

## Run

```
./run_capture.sh                 # capture_sbs_v3 with env set, record + preview
./run_capture.sh --duration 30   # 30 s
./run_capture.sh --no-record     # preview only
```

Environment (also in ~/.bashrc):
```
export DISPLAY=:0
export XAUTHORITY=*** /run/user/1000/.mutter-Xwaylandauth*)
export LD_LIBRARY_PATH=~/openeb/build/lib:~/openeb/build/lib/metavision/hal/plugins:$LD_LIBRARY_PATH
export MV_HAL_PLUGIN_PATH=~/openeb/build/lib/metavision/hal/plugins
```

## Notes

- Sync roles: master = 2629600159, slave = 2629600155.
- Slave starts first and emits ts==0 events until the master starts (normal).
- Benign startup errors: "TimeHigh discrepancy", one "Camera is busy (r=-6)" from process-cleanup race.
- Recordings: `~/captures/sbs_master_<sn>_<ts>.raw` + `sbs_slave_<sn>_<ts>.raw` (EVT2, replayable with these players or `metavision_player`).
- Binaries are not committed; rebuild with the command above.
