#!/bin/bash
# OCP dual DVS side-by-side capture launcher (v3 - hal_sync-clone pipeline)
source ~/.bashrc
export LD_LIBRARY_PATH=/home/astri/openeb/build/lib:/home/astri/openeb/build/lib/metavision/hal/plugins:$LD_LIBRARY_PATH
export MV_HAL_PLUGIN_PATH=/home/astri/openeb/build/lib/metavision/hal/plugins
cd /home/astri/ocp-capture
exec ./capture_sbs_v3 "$@"
