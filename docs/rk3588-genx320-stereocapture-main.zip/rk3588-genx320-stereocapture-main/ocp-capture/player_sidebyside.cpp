// OCP ART404CP — side-by-side player for paired dual-camera RAW files.
// Plays master + slave RAW files in one 640x320 window (master left, slave right),
// synced by timestamp. Keys: SPACE=pause, s=shot, q/ESC=quit.
//
// Usage: ./player_sidebyside <master.raw> <slave.raw> [--fps 25] [--accum-ms 50]
//                            [--gray] [--outdir DIR]
// Tip: if both files share the timestamped name from capture_sidebyside you can
// pass the prefix and it resolves sbs_master_*.raw / sbs_slave_*.raw.

#include <metavision/sdk/stream/camera.h>
#include <metavision/sdk/core/algorithms/base_frame_generation_algorithm.h>
#include <metavision/sdk/base/events/event_cd.h>

#include <opencv2/opencv.hpp>

#include <atomic>
#include <chrono>
#include <filesystem>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>

namespace fs = std::filesystem;

static std::string resolve_file(const std::string &arg, const std::string &role) {
    // if exact path given and exists, use it
    if (fs::exists(arg)) return arg;
    // try prefix matching: <prefix>/sbs_<role>_*.raw  (latest)
    fs::path p(arg);
    std::string dir = p.has_parent_path() ? p.parent_path().string()
                                          : (getenv("HOME") ? std::string(getenv("HOME")) + "/captures" : ".");
    std::string best;
    auto ftime = fs::file_time_type::min();
    for (auto &e : fs::directory_iterator(dir)) {
        std::string name = e.path().filename().string();
        if (name.rfind("sbs_" + role + "_", 0) == 0 && e.path().extension() == ".raw") {
            auto t = fs::last_write_time(e.path());
            if (t > ftime) { ftime = t; best = e.path().string(); }
        }
    }
    return best;
}

struct Player {
    std::unique_ptr<Metavision::Camera> cam;
    cv::Mat frame;
    std::mutex m;
    std::atomic<bool> paused{false};
    uint32_t accum_us;
    Metavision::ColorPalette palette;

    Player(const std::string &path, uint32_t accum, bool gray, const std::string &label)
        : accum_us(accum),
          palette(gray ? Metavision::ColorPalette::Gray : Metavision::ColorPalette::Dark) {
        cam = std::make_unique<Metavision::Camera>(Metavision::Camera::from_file(path));
        const auto &geo = cam->geometry();
        frame = cv::Mat(geo.get_height(), geo.get_width(), CV_8UC3);
        std::cout << label << ": " << path << std::endl;
        cam->cd().add_callback([&](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            if (paused.load()) return;
            std::lock_guard<std::mutex> lk(m);
            Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(
                b, e, frame, accum_us, palette);
        });
    }
    void start() { cam->start(); }
    void stop() { try { cam->stop(); } catch (...) {} }
};

int main(int argc, char **argv) {
    if (argc < 3) {
        std::cerr << "usage: " << argv[0] << " <master.raw> <slave.raw> [--fps 25] [--accum-ms 50] "
                  << "[--gray] [--outdir DIR]\n"
                  << "  (paths can be a shared prefix: dir/sbs resolves to latest sbs_master_*/sbs_slave_*)\n"
                  << "keys: SPACE=pause, s=screenshot, q/ESC=quit\n";
        return 1;
    }
    std::string m_path = resolve_file(argv[1], "master");
    std::string s_path = resolve_file(argv[2], "slave");
    if (m_path.empty()) { std::cerr << "master file not found: " << argv[1] << "\n"; return 1; }
    if (s_path.empty()) { std::cerr << "slave file not found: " << argv[2] << "\n"; return 1; }

    double fps = 25.0;
    uint32_t accum_us = 50000;
    bool gray = false;
    std::string outdir;
    for (int i = 3; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--fps" && i+1 < argc) fps = atof(argv[++i]);
        else if (a == "--accum-ms" && i+1 < argc) accum_us = (uint32_t)(atof(argv[++i]) * 1000);
        else if (a == "--gray") gray = true;
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
    }
    if (!outdir.empty()) fs::create_directories(outdir);

    try {
        Player master(m_path, accum_us, gray, "master");
        Player slave(s_path, accum_us, gray, "slave");

        int W = master.frame.cols, H = master.frame.rows;
        cv::Mat canvas(H, W * 2, CV_8UC3);

        std::string win = "side-by-side player";
        cv::namedWindow(win, cv::WINDOW_AUTOSIZE);

        master.start();
        slave.start();

        auto interval = std::chrono::milliseconds((int)(1000.0 / fps));
        auto last_show = std::chrono::steady_clock::now();
        int shot = 0;

        while (true) {
            auto now = std::chrono::steady_clock::now();
            if (now - last_show < interval) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
                continue;
            }
            last_show = now;
            {
                std::lock_guard<std::mutex> lkM(master.m), lkS(slave.m);
                master.frame.copyTo(cv::Mat(canvas, cv::Rect(0, 0, W, H)));
                slave.frame.copyTo(cv::Mat(canvas, cv::Rect(W, 0, W, H)));
            }
            std::string hud = std::string(master.paused ? "[PAUSED] " : "") +
                "M:" + fs::path(m_path).filename().string().substr(0, 28) +
                "  S:" + fs::path(s_path).filename().string().substr(0, 28);
            cv::putText(canvas, hud, {10, 20}, cv::FONT_HERSHEY_SIMPLEX, 0.45, {0,255,0}, 1);
            cv::imshow(win, canvas);

            int key = cv::waitKey(1) & 0xff;
            if (key == 'q' || key == 27) break;
            else if (key == ' ') { bool p = !master.paused.load(); master.paused.store(p); slave.paused.store(p); }
            else if (key == 's' && !outdir.empty()) {
                cv::imwrite(outdir + "/sbs_shot_" + std::to_string(++shot) + ".png", canvas);
                std::cout << "saved shot " << shot << "\n";
            }
        }
        master.stop(); slave.stop();
        std::cout << "done\n";
    } catch (const Metavision::CameraException &e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
