#!/bin/bash
# Manual replication of metavision_hal_sync flow, using our binaries
export LD_LIBRARY_PATH=/home/astri/openeb/build/lib:/home/astri/openeb/build/lib/metavision/hal/plugins:$LD_LIBRARY_PATH
export MV_HAL_PLUGIN_PATH=/home/astri/openeb/build/lib/metavision/hal/plugins
export DISPLAY=:10
export QT_QPA_PLATFORM=xcb
cd /home/astri/ocp-capture
# start SLAVE first (per hal_sync doc), 8 seconds
timeout 10 ./capture_single --serial 2629600155 --mode slave --duration 8 --outdir /tmp >/tmp/slave_log.txt 2>&1 &
SLAVE_PID=$!
sleep 2
# start MASTER
timeout 10 ./capture_single --serial 2629600159 --mode master --duration 6 --outdir /tmp | grep -v USB3
wait $SLAVE_PID
ls -la /tmp/single_2629600155*.raw /tmp/single_2629600159*.raw | tail -2
