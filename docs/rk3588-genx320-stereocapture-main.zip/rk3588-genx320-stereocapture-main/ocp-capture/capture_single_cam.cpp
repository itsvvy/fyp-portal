// OCP ART404CP — single-camera (slave 2629600159) capture with raw recording.
// Opens the given serial, programs sync mode (default standalone), records raw.
//
// Usage:
//   ./capture_single [--serial 2629600159] [--mode standalone|master|slave]
//                    [--duration SEC(0=until-Ctrl-C)] [--outdir DIR]
#include <metavision/hal/device/device.h>
#include <metavision/sdk/stream/camera.h>
#include <metavision/sdk/base/events/event_cd.h>
#include <metavision/hal/facilities/i_camera_synchronization.h>
#include <metavision/hal/facilities/i_events_stream.h>
#include <metavision/hal/facilities/i_events_stream_decoder.h>
#include <metavision/hal/facilities/i_event_decoder.h>
#include <metavision/hal/facilities/i_hw_identification.h>

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <signal.h>
#include <string>
#include <thread>

static std::atomic<bool> g_run{true};
static void sig_handler(int) { g_run = false; }

int main(int argc, char **argv) {
    std::string serial = "2629600159";
    std::string mode = "standalone";
    double duration = 0;
    std::string outdir = (getenv("HOME") ? std::string(getenv("HOME")) : std::string(".")) + "/captures";
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--serial" && i+1 < argc) serial = argv[++i];
        else if (a == "--mode" && i+1 < argc) mode = argv[++i];
        else if (a == "--duration" && i+1 < argc) duration = atof(argv[++i]);
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (a == "-h" || a == "--help") {
            std::cout << "usage: capture_single [--serial SN] [--mode standalone|master|slave] [--duration SEC] [--outdir DIR]\n";
            return 0;
        }
    }
    std::filesystem::create_directories(outdir);
    signal(SIGINT, sig_handler);

    try {
        std::cout << "opening camera " << serial << "...\n";
        auto cam = std::make_unique<Metavision::Camera>(Metavision::Camera::from_serial(serial));

        auto sync = cam->get_device().get_facility<Metavision::I_CameraSynchronization>();
        bool ok = false;
        if (mode == "master") ok = sync->set_mode_master();
        else if (mode == "slave") ok = sync->set_mode_slave();
        else ok = sync->set_mode_standalone();
        if (!ok) { std::cerr << "ERROR: set mode " << mode << " failed\n"; return 1; }
        std::cout << "mode " << mode << " OK\n";

        // event counting
        std::atomic<uint64_t> n_events{0};
        auto *cd_dec = cam->get_device().get_facility<Metavision::I_EventDecoder<Metavision::EventCD>>();
        cd_dec->add_event_buffer_callback([&n_events](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            n_events += std::distance(b, e);
        });

        // start raw logging BEFORE streaming
        auto t = std::time(nullptr);
        char buf[32]; std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", std::localtime(&t));
        std::string path = outdir + "/single_" + serial + "_" + mode + "_" + buf + ".raw";
        auto *es = cam->get_device().get_facility<Metavision::I_EventsStream>();
        es->log_raw_data(path);
        std::cout << "recording: " << path << "\n";

        cam->start();
        std::cout << "streaming... Ctrl-C to stop\n";
        auto t0 = std::chrono::steady_clock::now();
        auto last = t0;
        uint64_t prev = 0;
        while (g_run) {
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last).count() >= 1.0) {
                double el = std::chrono::duration<double>(now - t0).count();
                std::cout << "[" << (int)el << "s] " << (n_events - prev) << " ev/s\n" << std::flush;
                prev = n_events;
                last = now;
                if (duration > 0 && el >= duration) break;
            }
        }
        cam->stop();
        es->stop_log_raw_data();
        std::cout << "total: " << n_events << " events\n";
    } catch (const Metavision::CameraException &e) {
        std::cerr << "CameraException: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
