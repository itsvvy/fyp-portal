// OCP ART404CP — dual GenX320 capture, master/slave sync, raw recording via HAL log_raw_data
#include <metavision/hal/device/device.h>
#include <metavision/sdk/base/events/event_cd.h>
#include <metavision/sdk/stream/camera.h>
#include <metavision/hal/facilities/i_camera_synchronization.h>
#include <metavision/hal/facilities/i_events_stream.h>
#include <metavision/hal/facilities/i_events_stream_decoder.h>
#include <metavision/hal/facilities/i_event_decoder.h>
#include <metavision/hal/facilities/i_hw_identification.h>

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <signal.h>
#include <string>
#include <thread>

static std::atomic<bool> g_run{true};
static void sig_handler(int) { g_run = false; }

struct CamCapture {
    std::string serial, label;
    Metavision::I_EventsStream *es = nullptr;
    Metavision::I_EventsStreamDecoder *esd = nullptr;
    Metavision::I_EventDecoder<Metavision::EventCD> *cd_dec = nullptr;
    std::atomic<uint64_t> n_events{0};
    std::atomic<int64_t> last_ts{-1};

    CamCapture(Metavision::Device *d, const std::string &sn, const std::string &lb)
        : serial(sn), label(lb) {
        es  = d->get_facility<Metavision::I_EventsStream>();
        esd = d->get_facility<Metavision::I_EventsStreamDecoder>();
        cd_dec = d->get_facility<Metavision::I_EventDecoder<Metavision::EventCD>>();
        cd_dec->add_event_buffer_callback([this](const Metavision::EventCD *b, const Metavision::EventCD *e) {
            n_events += std::distance(b, e);
            if (b != e) last_ts = (e - 1)->t;
        });
    }
    void start() { es->start(); }
    void poll() {
        if (es->poll_buffer() == 1) { esd->decode(es->get_latest_raw_data()); }
    }
    void stop() { try { es->stop(); } catch (...) {} }
};

static void log_start(Metavision::Camera &cam, const std::string &path) {
    auto *es = cam.get_device().get_facility<Metavision::I_EventsStream>();
    es->log_raw_data(path);
}
static void log_stop(Metavision::Camera &cam) {
    auto *es = cam.get_device().get_facility<Metavision::I_EventsStream>();
    es->stop_log_raw_data();
}

int main(int argc, char **argv) {
    std::string master_sn = "2629600155";
    std::string slave_sn = "2629600159";
    double duration = 0; // 0 = until Ctrl-C
    std::string outdir = (getenv("HOME") ? std::string(getenv("HOME")) : std::string(".")) + "/captures";
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--master-serial" && i+1 < argc) master_sn = argv[++i];
        else if (a == "--slave-serial" && i+1 < argc) slave_sn = argv[++i];
        else if (a == "--duration" && i+1 < argc) duration = atof(argv[++i]);
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (a == "-h" || a == "--help") {
            std::cout << "usage: capture_dual_dvs [--master-serial SN] [--slave-serial SN] [--duration SEC] [--outdir DIR]\n";
            return 0;
        }
    }
    std::filesystem::create_directories(outdir);
    signal(SIGINT, sig_handler);

    try {
        std::cout << "opening master " << master_sn << "...\n";
        auto cam_m = std::make_unique<Metavision::Camera>(Metavision::Camera::from_serial(master_sn));
        std::cout << "opening slave " << slave_sn << "...\n";
        auto cam_s = std::make_unique<Metavision::Camera>(Metavision::Camera::from_serial(slave_sn));

        auto sync_m = cam_m->get_device().get_facility<Metavision::I_CameraSynchronization>();
        auto sync_s = cam_s->get_device().get_facility<Metavision::I_CameraSynchronization>();
        if (!sync_m->set_mode_master()) { std::cerr << "ERROR: set master failed\n"; return 1; }
        if (!sync_s->set_mode_slave())  { std::cerr << "ERROR: set slave failed\n";  return 1; }
        std::cout << "sync programmed OK\n";

        CamCapture m(&cam_m->get_device(), master_sn, "master");
        CamCapture s(&cam_s->get_device(), slave_sn, "slave");

        auto t = std::time(nullptr);
        char buf[32]; std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", std::localtime(&t));
        std::string stamp(buf);
        std::string f_m = outdir + "/master_" + master_sn + "_" + stamp + ".raw";
        std::string f_s = outdir + "/slave_" + slave_sn + "_" + stamp + ".raw";
        log_start(*cam_m, f_m);
        log_start(*cam_s, f_s);
        std::cout << "recording:\n  " << f_m << "\n  " << f_s << "\n";

        m.start();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        s.start();
        std::cout << "streaming... Ctrl-C to stop\n";

        auto t0 = std::chrono::steady_clock::now();
        auto last = t0;
        uint64_t pm = 0, ps = 0;
        while (g_run) {
            m.poll(); s.poll();
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last).count() >= 1.0) {
                double el = std::chrono::duration<double>(now - t0).count();
                std::cout << "[" << (int)el << "s] master: " << (m.n_events - pm)
                          << " ev/s | slave: " << (s.n_events - ps)
                          << " ev/s | slave_last_ts: " << s.last_ts.load() << "\n" << std::flush;
                pm = m.n_events; ps = s.n_events;
                last = now;
                if (duration > 0 && el >= duration) break;
            }
        }
        m.stop(); s.stop();
        log_stop(*cam_m); log_stop(*cam_s);
        std::cout << "totals: master=" << m.n_events << " slave=" << s.n_events << "\n";
    } catch (const Metavision::CameraException &e) {
        std::cerr << "CameraException: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
