// OCP ART404CP — dual GenX320 capture: master+slave side-by-side in ONE raw file
// + live preview window (side-by-side, 640x320).
//
// One RAW file contains both cameras' events: since both cameras are time-synced
// (shared time base), their EventCD streams are merged in timestamp order into a
// single EVT2 raw via RAWEventFileLogger. Master occupies x<320, slave x>=320 —
// the offset is applied to slave events' x coordinate so one 640x320 virtual
// sensor holds both views.
//
// Live preview: OpenCV window (side-by-side canvas).
//
// Usage:
//   ./capture_sidebyside [--master-serial 2629600159] [--slave-serial 2629600155]
//        [--duration SEC(0=until-Ctrl-C)] [--outdir ~/captures] 
//        [--accum-ms 33] [--no-record]

#include <metavision/hal/device/device.h>
#include <metavision/sdk/stream/camera.h>
#include <metavision/hal/facilities/i_events_stream.h>
#include <metavision/sdk/stream/synced_camera_system_factory.h>
#include <metavision/sdk/stream/synced_camera_streams_slicer.h>
#include <metavision/sdk/stream/raw_event_file_logger.h>
#include <metavision/sdk/core/algorithms/base_frame_generation_algorithm.h>
#include <metavision/sdk/base/events/event_cd.h>

#include <opencv2/opencv.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <signal.h>
#include <string>
#include <thread>

static std::atomic<bool> g_run{true};
static void sig_handler(int) { g_run = false; }

int main(int argc, char **argv) {
    std::string master_sn = "2629600159";
    std::string slave_sn = "2629600155";
    double duration = 0;
    std::string outdir = (getenv("HOME") ? std::string(getenv("HOME")) : std::string(".")) + "/captures";
    uint32_t accum_us = 33000;
    bool record = true;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--master-serial" && i+1 < argc) master_sn = argv[++i];
        else if (a == "--slave-serial" && i+1 < argc) slave_sn = argv[++i];
        else if (a == "--duration" && i+1 < argc) duration = atof(argv[++i]);
        else if (a == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (a == "--accum-ms" && i+1 < argc) accum_us = (uint32_t)(atof(argv[++i]) * 1000);
        else if (a == "--no-record") record = false;
        else if (a == "-h" || a == "--help") {
            std::cout << "usage: capture_sidebyside [--master-serial SN] [--slave-serial SN] "
                      << "[--duration SEC] [--outdir DIR]  "
                      << "[--accum-ms MS] [--no-record]\n";
            return 0;
        }
    }
    std::filesystem::create_directories(outdir);
    signal(SIGINT, sig_handler);

    try {
        // 1) build synced camera system (factory programs master/slave modes itself)
        Metavision::SyncedCameraSystemFactory::LiveParameters lp;
        lp.record = false;
        Metavision::SyncedCameraSystemFactory::LiveCameraParameters mp;
        mp.serial_number = master_sn;
        Metavision::SyncedCameraSystemFactory::LiveCameraParameters sp;
        sp.serial_number = slave_sn;
        lp.master_parameters = mp;
        lp.slave_parameters = {sp};

        std::cout << "building synced system (master " << master_sn
                  << ", slave " << slave_sn << ")...\n";
        auto [master_cam, slave_cams] = Metavision::SyncedCameraSystemFactory::build(lp);
        std::cout << "master: " << master_sn << "\n";
        std::cout << "slaves: " << slave_cams.size() << "\n";
        for (auto &sc : slave_cams)
            std::cout << "  " << slave_sn << "\n";

        // geometry: master is 320x320; combined canvas 640x320
        const int W = master_cam.geometry().get_width();
        const int H = master_cam.geometry().get_height();
        const int CW = W * (1 + slave_cams.size());
        std::cout << "combined canvas: " << CW << "x" << H << "\n";

        // 2) recording: RAW cannot hold decoded events, so record merged decoded
        // events to a DAT file (Metavision DAT format) via DATEventFileWriter if
        // available; fallback: two RAW files via per-camera log_raw_data.
        // We record TWO raw files (hw-side, reliable) named with shared timestamp,
        // and additionally write merged decoded events to CSV if --csv.
        std::string raw_path_m, raw_path_s;
        if (record) {
            auto t = std::time(nullptr);
            char buf[32]; std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", std::localtime(&t));
            raw_path_m = outdir + "/sbs_master_" + master_sn + "_" + buf + ".raw";
            raw_path_s = outdir + "/sbs_slave_" + slave_sn + "_" + buf + ".raw";
        }

        // 3) event buffers: master raw offset 0, slave raw offset W
        std::vector<Metavision::EventCD> master_buf, slave_buf;
        std::mutex buf_m;

        // NOTE: with the SyncedCameraStreamsSlicer we get per-slice buffers already
        // separated (master_events, slave_events). We merge into a single sorted
        // buffer with the slave x-offset applied, then write to raw logger.
        // For raw writing we need the actual raw bytes; simplest correct approach:
        // use each camera's raw stream via add_raw_data on the logger — but the
        // logger writes EVT2 with its own header. Instead we write decoded events
        // via add_events (the RAWEventFileLogger supports event writing too).
        //
        // So: merged decoded event file (EVT2 raw). Slave events x-offset by W.

        // 4) frame gen for preview: two separate 320x320 frames side by side
        cv::Mat frame_m(H, W, CV_8UC3), frame_s(H, W, CV_8UC3);
        std::mutex fm_m;
        auto palette = Metavision::ColorPalette::Dark;
        uint64_t ev_m = 0, ev_s = 0;

        // 5) start hw-side raw logging on both cameras
        {
            auto *esm = master_cam.get_device().get_facility<Metavision::I_EventsStream>();
            esm->log_raw_data(raw_path_m);
            for (size_t i = 0; i < slave_cams.size(); ++i) {
                auto *ess = slave_cams[i].get_device().get_facility<Metavision::I_EventsStream>();
                ess->log_raw_data(i == 0 ? raw_path_s : raw_path_s + "." + std::to_string(i));
            }
        }

        // 6) slicing
        auto cond = Metavision::EventBufferReslicerAlgorithm::Condition::make_n_us(10000); // 10ms slices
        // move cameras into slicer
        auto slicer = Metavision::SyncedCameraStreamsSlicer(std::move(master_cam),
                                                            std::move(slave_cams), cond);


        cv::Mat canvas(H, CW, CV_8UC3);
        std::string win = "OCP side-by-side (master | slave)";
        cv::namedWindow(win, cv::WINDOW_AUTOSIZE);

        std::cout << "streaming... Ctrl-C to stop\n";
        auto t0 = std::chrono::steady_clock::now();
        auto last_report = t0;
        uint64_t rm = 0, rs = 0;
        int slice_count = 0;

        for (const auto &slice : slicer) {
            if (!g_run) break;
            // write merged events to raw
            // (recording happens hw-side via log_raw_data; nothing to do here)

            // preview frames
            {
                std::lock_guard<std::mutex> lk(fm_m);
                Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(
                    slice.master_events->cbegin(), slice.master_events->cend(), frame_m, accum_us, palette);
                for (auto &sep : slice.slave_events) {
                    Metavision::BaseFrameGenerationAlgorithm::generate_frame_from_events(
                        sep->cbegin(), sep->cend(), frame_s, accum_us, palette);
                }
            }

            ev_m += slice.n_events;
            for (auto &sep : slice.slave_events) ev_s += sep->size();

            // compose canvas + show
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last_report).count() >= (1000.0/30.0)) {
                {
                    std::lock_guard<std::mutex> lk(fm_m);
                    frame_m.copyTo(cv::Mat(canvas, cv::Rect(0, 0, W, H)));
                    frame_s.copyTo(cv::Mat(canvas, cv::Rect(W, 0, W, H)));
                }
                std::string hud = "M:" + std::to_string(ev_m) + " S:" + std::to_string(ev_s)
                                + (record ? " [REC]" : "");
                cv::putText(canvas, hud, {10, 20}, cv::FONT_HERSHEY_SIMPLEX, 0.5, {0,255,0}, 1);
                cv::imshow(win, canvas);
                int key = cv::waitKey(1) & 0xff;
                if (key == 'q' || key == 27) break;
                last_report = now;
            }

            if (duration > 0) {
                auto el = std::chrono::duration<double>(now - t0).count();
                if (el >= duration) break;
            }
        }

        if (record) { std::cout << "\nraw saved:\n  " << raw_path_m << "\n  " << raw_path_s << "\n"; }
        std::cout << "totals: master=" << ev_m << " slave=" << ev_s << "\n";
    } catch (const Metavision::CameraException &e) {
        std::cerr << "CameraException: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
